package com.spring.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.spring.model.Customer;

@Controller
public class CustomerController {
	@RequestMapping("/load")
	//@ResponseBody
	public String loadMyJspFile(@ModelAttribute("custObj") Customer cust)
	{
		return "login";
	}
	// for get method
	//@RequestMapping("/login")
	//if we use post method
	@RequestMapping(value="/login", method=RequestMethod.POST)

	public ModelAndView doLogin(@ModelAttribute("custObj") Customer cust) 
	{
		ModelAndView model=new ModelAndView();
		model.addObject("customer", cust);
		model.setViewName("Myfile");
		return model;
	}
	
	
		
	

}
