package com.springProject.Repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springProject.Model.practice;
@Repository
public interface practiceRepository extends JpaRepository<practice, Integer> {
//	public Optional<practice> findBypracticeId(int practiceId);
	@Modifying(clearAutomatically = true)
	@Transactional
	@Query(value="Update happy set practicedesc= ?2 ,set priority= ?3 WHERE practiceId = ?1", nativeQuery=true)
	int updateBypracticeId(int  practiceId,String practicedesc,int priority);
	

}
