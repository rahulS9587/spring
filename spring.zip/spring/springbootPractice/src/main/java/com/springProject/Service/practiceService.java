package com.springProject.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.springProject.Model.practice;

public interface practiceService {
//	public void addPractice(practice product);
	public ResponseEntity<Void> UpdateByPracticeId(practice product,int practiceId);
	public Optional<practice> findBypracticeId(int practiceId);
	
	public List<practice> findAllpractice();


}
