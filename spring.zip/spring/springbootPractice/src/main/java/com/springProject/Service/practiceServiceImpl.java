package com.springProject.Service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.springProject.Exception.ResourceNotFoundException;
import com.springProject.Model.practice;
import com.springProject.Repository.practiceRepository;

@Service
public class practiceServiceImpl implements practiceService {

	@Autowired
	practiceRepository practicerepository;

	/*
	 * @Override public void addPractice(practice product) {
	 * practicerepository.save(product);
	 * 
	 * }
	 */

	@Override
	public Optional<practice> findBypracticeId(int practiceId) {
		Optional<practice> product = practicerepository.findById(practiceId);
		return product;
	}

	@Override
	public ResponseEntity<Void> UpdateByPracticeId(practice product, int practiceId) {
		practice practice1 = practicerepository.findById(practiceId).orElse(null);
		if (practice1 == null) {
			throw new ResourceNotFoundException("Id not found");
		} else if ((product.getPracticedesc()).isEmpty() || product.getPracticedesc() == null) {
			throw new ResourceNotFoundException("Description is required");
		} else if ((product.getPriority()).isEmpty() || product.getPriority() == null) {
			throw new ResourceNotFoundException("Priority is required");
		} else {
			practicerepository.save(product);
			return new ResponseEntity<Void>(HttpStatus.OK);

		}
	}

	@Override
	public List<practice> findAllpractice() {
		List<practice> product = practicerepository.findAll();
		return product;
	}
}
