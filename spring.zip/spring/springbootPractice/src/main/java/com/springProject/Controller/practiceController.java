package com.springProject.Controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springProject.Exception.ResourceNotFoundException;
import com.springProject.Model.practice;
import com.springProject.Service.practiceService;

@RestController
@RequestMapping("/v")
public class practiceController {

	@Autowired
	practiceService practiceservice;
	/*
	 * @RequestMapping(value = "/add", method = RequestMethod.POST) public
	 * ResponseEntity<Void> addpractice(@Valid @RequestBody practice product) {
	 * practiceservice.addPractice(product); return new
	 * ResponseEntity<Void>(HttpStatus.OK);
	 * 
	 * }
	 */

	@GetMapping("getAll")
	public List<practice> findAllpractice() {
		List<practice> product = practiceservice.findAllpractice();
		return product;
	}

	@PutMapping("update/{practiceId}")
	public practice UpdateByPracticeId(@RequestBody practice product, @PathVariable("practiceId") int practiceId) {
		practiceservice.UpdateByPracticeId(product, practiceId);
		return product;

	}



	@GetMapping("/find/{practiceId}")
	public ResponseEntity<practice>findByProductId(@PathVariable("practiceId") int practiceId)
	{
	  Optional<practice> product = practiceservice.findBypracticeId(practiceId); 
	  if(product.isPresent()) {
		  return ResponseEntity.ok(product.get()); } 
	  throw new ResourceNotFoundException("invalid product id");
	  }
}
