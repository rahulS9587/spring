package com.springProject.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="Happy")
public class practice{
	@Id
	int practiceId;
	
	String practicedesc;
	String priority;
	public practice() {
		super();
		// TODO Auto-generated constructor stub
	}
	public practice(int practiceId, String practicedesc, String priority) {
		super();
		this.practiceId = practiceId;
		this.practicedesc = practicedesc;
		this.priority=priority;
	}
	public int getPracticeId() {
		return practiceId;
	}
	public void setPracticeId(int practiceId) {
		this.practiceId = practiceId;
	}
	public String getPracticedesc() {
		return practicedesc;
	}
	public void setPracticedesc(String practicedesc) {
		this.practicedesc = practicedesc;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	@Override
	public String toString() {
		return "practice [practiceId=" + practiceId + ", practicedesc=" + practicedesc + ", priority=" + priority + "]";
	}
	
	
	
}
