package com.microservice.service;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.microservice.Exception.ResourceNotFoundException;
import com.microservice.externalServices.HotelService;
import com.microservice.model.Hotel;
import com.microservice.model.Rating;
import com.microservice.model.User;
import com.microservice.repository.userRepository;


@Service
public class userServiceImpl implements userService {

	@Autowired
	private userRepository userRepo;

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private HotelService hotelservice;
	
	   

	Logger logger = LoggerFactory.getLogger(userServiceImpl.class);

	@Override
	public User saveUser(User user) {
		String randomUserId = UUID.randomUUID().toString();
		user.setuserid(randomUserId);
		return userRepo.save(user);

	}

	@Override
	public List<User> getAllUsers() {
		return userRepo.findAll();
	}

	@Override
	public User getUser(String userid) {
		User user = userRepo.findById(userid).orElseThrow(() -> new ResourceNotFoundException("user with this given id is not found!!"));
		
        Rating[] ratingsOfUser = restTemplate.getForObject("http://RATINGSERVICE/ratings/users/" + user.getuserid(), Rating[].class);
		//ArrayList<Rating> ratingsOfuser = restTemplate.getForObject("http://RATINGSERVICE/ratings/user/" + user.getuserid(),ArrayList.class);
		logger.info("{}", ratingsOfUser);
		
	        
	     //   List<Rating> ratings = Arrays.stream(ratingsOfUser).toList();
	      //  List<Rating> ratings = ratingsOfUser.stream().collect(Collectors.toList());
	        List<Rating> ratings = Arrays.stream(ratingsOfUser)
                    .collect(Collectors.toList());
	        List<Rating> ratingList = ratings.stream().map(rating -> {
	            //api call to hotel service to get the hotel
	            //http://localhost:8082/hotels/1cbaf36d-0b28-4173-b5ea-f1cb0bc0a791
	            ResponseEntity<Hotel> forEntity = restTemplate.getForEntity("http://HOTELSERVICE/hotels/"+rating.getHotelId(), Hotel.class);
	            Hotel hotel = hotelservice.getHotel(rating.getHotelId());
	             logger.info("response status code: {} ",forEntity.getStatusCode());
	            //set the hotel to rating
	            rating.setHotel(hotel);
	            //return the rating
	            return rating;
	        }).collect(Collectors.toList());

	        user.setRatings(ratingList);

		return user;

	}

}
