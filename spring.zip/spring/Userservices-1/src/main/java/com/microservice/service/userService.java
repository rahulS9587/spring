package com.microservice.service;

import java.util.List;

import com.microservice.model.User;

public interface userService {
	
	public User saveUser(User user);
	
	public List<User> getAllUsers();
	
	
	public User getUser(String userid);

}
