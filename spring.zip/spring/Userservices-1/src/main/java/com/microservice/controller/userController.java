package com.microservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.microservice.model.User;
import com.microservice.service.userService;
import com.microservice.service.userServiceImpl;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.ratelimiter.annotation.RateLimiter;
import io.github.resilience4j.retry.annotation.Retry;

@RestController
@RequestMapping("/users")
public class userController {

	@Autowired
	private userService userservice;

	Logger logger = LoggerFactory.getLogger(userServiceImpl.class);

	@PostMapping("/save")
	public ResponseEntity<User> createUser(@RequestBody User user) {
		User user1 = userservice.saveUser(user);

		return ResponseEntity.status(HttpStatus.OK).body(user1);

	}

	@GetMapping("/get/{userid}")
//	@CircuitBreaker(name = "ratingBreaker", fallbackMethod = "ratingFallback")
	@Retry(name = "ratingBreaker", fallbackMethod = "ratingFallback")
	public ResponseEntity<User> getUserById(@PathVariable String userid) {
		return ResponseEntity.status(HttpStatus.OK).body(userservice.getUser(userid));
	}

	// creating fallback method for circuit breaker
	int retryCount=1;
	@RateLimiter(name="useRateLimiter", fallbackMethod = "ratingFallback")
	public ResponseEntity<User> ratingFallback(String userid, Exception ex) {
		//logger.info("fallback is executed because service is down", ex.getMessage());
		logger.info("Retry count:{} ",retryCount);
		retryCount++;

		User user = new User();
		return new ResponseEntity<>(user, HttpStatus.OK);

	}

	@GetMapping("/getAll")
	public ResponseEntity<List<User>> getAllUser() {
		List<User> getall = userservice.getAllUsers();
		return ResponseEntity.ok(getall);

	}

}
