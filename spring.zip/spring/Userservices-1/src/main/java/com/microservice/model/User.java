package com.microservice.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.Id;


@Entity
@Table(name="user")
public class User {
	
	@Id
	private  String userid;	
	private String Name;
	private String email;
	private String about;
	
	@Transient
	private List<Rating> ratings=new ArrayList<>();
	
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}


	

	public User(String userid, String name, String email, String about, List<Rating> ratings) {
		super();
		this.userid = userid;
		Name = name;
		this.email = email;
		this.about = about;
		this.ratings = ratings;
	}




	public String getuserid() {
		return userid;
	}


	public void setuserid(String userid) {
		this.userid = userid;
	}


	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getAbout() {
		return about;
	}


	public void setAbout(String about) {
		this.about = about;
	}




	public List<Rating> getRatings() {
		return ratings;
	}




	public void setRatings(List<Rating> ratings) {
		this.ratings = ratings;
	}
	


	
	
	

}
