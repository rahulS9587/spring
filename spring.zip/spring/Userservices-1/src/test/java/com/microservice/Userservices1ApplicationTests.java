package com.microservice;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.microservice.externalServices.RatingService;


@SpringBootTest
class Userservices1ApplicationTests {

	@Test
	void contextLoads() {
	}
	
	@Autowired
	RatingService ratingservice;
	
//	@Test
//	void createRating() {
//		Rating rating=new Rating( "ratingId","feedback","userId","hotelId",10);
//	//	Rating savedrating=ratingservice.createRating(rating);
//		System.out.println("new rating created: ");
//		
//	}

}
