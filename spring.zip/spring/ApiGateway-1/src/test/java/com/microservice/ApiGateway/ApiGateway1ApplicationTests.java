package com.microservice.ApiGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiGateway1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
