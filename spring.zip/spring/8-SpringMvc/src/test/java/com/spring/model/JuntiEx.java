package com.spring.model;

import junit.framework.TestCase;

public class JuntiEx extends TestCase {

}
