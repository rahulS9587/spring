package com.spring.Controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CustomerController {
	@RequestMapping("/load")
	// @ResponseBody
	public String loadMyJspFile() {
		return "Myfile";
	}
	// for get method
	// @RequestMapping("/login")
	// if we use post method
//	@RequestMapping(value="/login", method=RequestMethod.POST)

	public ModelAndView doLogin(@RequestParam("username") String uname, @RequestParam("address") String add) {
		ModelAndView model = new ModelAndView();
		model.addObject("Username", uname);
		model.addObject("address", add);
		model.setViewName("Myfile");
		return model;
	}

}
