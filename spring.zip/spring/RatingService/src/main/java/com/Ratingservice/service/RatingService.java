package com.Ratingservice.service;

import java.util.List;

import com.Ratingservice.model.Rating;

public interface RatingService {
	
	public Rating create(Rating rating);
	
	public List<Rating> getAll();
	
	public List<Rating> getByuserId(String userId);
	
	public List<Rating> getByhotelId(String hotelId);

}
