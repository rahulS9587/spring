package com.Ratingservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user_ratings")
public class Rating {
	
	@Id
	private String ratingId;
	private String feedback;
	
	@Column(name="user_id")
	private String userId;
	
	@Column(name="hotel_id")
	private String hotelId;
	private int Rating;
	public Rating() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Rating(String ratingId, String feedback, String userid, String hotelId, int rating) {
		super();
		this.ratingId = ratingId;
		this.feedback = feedback;
		this.userId = userid;
		this.hotelId = hotelId;
		this.Rating = rating;
	}
	public String getRatingId() {
		return ratingId;
	}
	public void setRatingId(String ratingId) {
		this.ratingId = ratingId;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userid) {
		this.userId = userid;
	}
	public String getHotelId() {
		return hotelId;
	}
	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}
	public int getRating() {
		return Rating;
	}
	public void setRating(int rating) {
		Rating = rating;
	}
	
	

}
