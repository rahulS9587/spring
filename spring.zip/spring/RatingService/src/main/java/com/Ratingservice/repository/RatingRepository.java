package com.Ratingservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Ratingservice.model.Rating;

@Repository
public interface  RatingRepository extends JpaRepository<Rating, String>{
	public List<Rating> findByuserId(String userId);
	public List<Rating> findByhotelId(String hotelId);

	

}
