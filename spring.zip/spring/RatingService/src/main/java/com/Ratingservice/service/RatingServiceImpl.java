package com.Ratingservice.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ratingservice.model.Rating;
import com.Ratingservice.repository.RatingRepository;

@Service
public class RatingServiceImpl implements RatingService {
	
	@Autowired
	private RatingRepository ratingrepo;

	@Override
	public Rating create(Rating rating) {
		String randomRatingId=UUID.randomUUID().toString();
		rating.setRatingId(randomRatingId);
	
		return ratingrepo.save(rating) ;
		
	}

	@Override
	public List<Rating> getAll() {
	
		return ratingrepo.findAll();
	}

	@Override
	public List<Rating> getByuserId(String userId) {
	
		return ratingrepo.findByuserId(userId);
		
	}

	@Override
	public List<Rating> getByhotelId(String hotelId) {
	
		return ratingrepo.findByhotelId(hotelId);
		
	}

}
