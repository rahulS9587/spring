package com.springProject.Model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;


@Entity
public class ArticleDTO {
		
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private int id;
	private String title;
	private String content;
	
	@OneToOne(cascade = CascadeType.ALL)
	 List<Tag> tags;
	public ArticleDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ArticleDTO(int id, String title, String content, List<Tag> tags) {
		super();
		this.id = id;
		this.title = title;
		this.content = content;
		this.tags = tags;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public List<Tag> getTags() {
		return tags;
	}
	public void setTags(List<Tag> tags) {
		this.tags = tags;
	}
	@Override
	public String toString() {
		return "ArticleDTO [id=" + id + ", title=" + title + ", content=" + content + ", tags=" + tags + "]";
	}
	
}