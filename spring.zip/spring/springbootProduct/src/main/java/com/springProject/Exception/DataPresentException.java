package com.springProject.Exception;


public class DataPresentException extends RuntimeException {
	public DataPresentException(String message)
	{
		super(message);
	}

}
