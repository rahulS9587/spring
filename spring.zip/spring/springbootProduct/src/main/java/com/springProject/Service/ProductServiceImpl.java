package com.springProject.Service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springProject.Model.Product;
import com.springProject.Repository.ProductRepository;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepository productrepository;

	@Override
	public void addProduct(Product product) {
		productrepository.save(product);

	}

	@Override
	public List<Product> findAllProducts() {
		List<Product> product = productrepository.findAll();
		return product;
	}

	@Override
	public Product findByProductName(String productName) {
		Product product = productrepository.findByproductName(productName);

		return product;
	}

	@Override
	public void deleteByProductName(String productName) {
		productrepository.deleteByProductName(productName);

	}

	@Override
	public Optional<Product> findById(int productId) {
		Optional<Product> product = productrepository.findById(productId);

		return product;
	}

	@Override
	public Product updateProduct(Product product, int productId) {
		productrepository.findById(productId);
		String prod1 = product.getProductName();
		product.setProductName(prod1);
		int prod2=product.getProductcost();
		product.setProductcost(prod2);
		productrepository.save(product);
		
		return product;
		
	}

}
