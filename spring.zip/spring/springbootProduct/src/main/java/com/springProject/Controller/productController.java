package com.springProject.Controller;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.springProject.Model.Product;
import com.springProject.Model.Tag;
import com.springProject.Service.ProductService;
import com.springProject.Service.TagService;
import com.springProject.Exception.DataPresentException;
import com.springProject.Exception.ResourceNotFoundException;

@RestController
@RequestMapping("/v1")
public class productController {
	@Autowired
	ProductService productservice;

	@Autowired
	TagService tagservice;

	@PostMapping("/save")
	public ResponseEntity<Void> addProduct (@Value("${list}") List<String> list1, @Valid @RequestBody Product product) 
			throws DataPresentException
	{
		for (int i = 0; i < list1.size(); i++) {
			if (product.getProductName().matches(list1.get(i))) {
				throw new DataPresentException("Data is already present");
			}
		}
		productservice.addProduct(product);
		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
	}
	@RequestMapping(value = "/addtag", method = RequestMethod.POST)
	public void addTag(@RequestBody Tag tag) {
		tagservice.addTag(tag);

	}

	@RequestMapping("/getAll")
	public ResponseEntity<List<Product>> findAllProducts() {
		List<Product> product = productservice.findAllProducts();
		return new ResponseEntity<List<Product>>(product, HttpStatus.OK);

	}

	@RequestMapping("/get/{productName}")
	public Product findByProductName(@PathVariable("productName") String productName) {
		Product product = productservice.findByProductName(productName);
		return product;

	}

	@GetMapping("/get/{productId}")
	public ResponseEntity<Product> findByProductId(@PathVariable("productId") int productId) throws ResourceNotFoundException{
		Optional<Product> product = productservice.findById(productId);
		if (product.isPresent()) {
			return ResponseEntity.ok(product.get());
		}
		throw new ResourceNotFoundException("invalid product id");
	}

	@PutMapping("/product/{productId}")
	public ResponseEntity<Product> UpdateProduct(@Value("${list}") List<String> list1,
			@Valid @RequestBody Product product, @PathVariable("productId") int productId)
			throws ResourceNotFoundException {

		Optional<Product> prod = productservice.findById(productId);
		if (prod.isPresent()) {
			for (int i = 0; i < list1.size(); i++) {
				if (product.getProductName().matches(list1.get(i))) {
					throw new DataPresentException("Data is already present");
				}
			}
			productservice.updateProduct(product, productId);
			return ResponseEntity.ok(prod.get());
		}
		throw new ResourceNotFoundException("can't update the product");

	}

	@DeleteMapping("delete/{productname}")
	public void deletebyProductName(@PathVariable("productname") String productname) {
		productservice.deleteByProductName(productname);

	}
}
