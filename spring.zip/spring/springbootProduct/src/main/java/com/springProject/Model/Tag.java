package com.springProject.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Tag {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int article_id;
	private String tag;
	public Tag() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Tag(int article_id, String tag) {
		super();
		this.article_id = article_id;
		this.tag = tag;
	}
	public int getArticle_id() {
		return article_id;
	}
	public void setArticle_id(int article_id) {
		this.article_id = article_id;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	@Override
	public String toString() {
		return "Tag [article_id=" + article_id + ", tag=" + tag + "]";
	}
	
	
}