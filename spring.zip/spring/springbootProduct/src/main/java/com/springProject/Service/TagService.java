package com.springProject.Service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springProject.Model.Tag;
import com.springProject.Repository.TagRepository;

@Service
@Transactional
public class TagService {
	@Autowired
	TagRepository tagrepository;

	public void addTag(Tag tag) {
		tagrepository.save(tag);
	}

}
