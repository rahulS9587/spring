package com.springProject.Service;

import java.util.List;
import java.util.Optional;

import com.springProject.Model.Product;

public interface ProductService {
	public void addProduct(Product product);

	public List<Product> findAllProducts();

	public Product findByProductName(String productName);

	public Optional<Product> findById(int productId);

	public void deleteByProductName(String productName);

	public Product updateProduct(Product product, int productId);

}
