package com.springProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootProductApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootProductApplication.class, args);
		System.out.println("project created");
	}

}
