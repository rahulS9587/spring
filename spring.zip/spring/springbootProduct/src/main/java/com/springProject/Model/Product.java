package com.springProject.Model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int productId;

	@NotEmpty(message = "productName is required")
	String productName;
	@NotNull
	int productcost;
	@OneToOne(cascade = CascadeType.ALL)
	Tag tag;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(int productId, int productcost, String productName, Tag tag) {
		super();
		this.productId = productId;
		this.productcost = productcost;
		this.productName = productName;
		this.tag = tag;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getProductcost() {
		return productcost;
	}

	public void setProductcost(int productcost) {
		this.productcost = productcost;
	}

	public Tag getTag() {
		return tag;
	}

	public void setTag(Tag tag) {
		this.tag = tag;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productcost=" + productcost
				+ ", tag=" + tag + "]";
	}

}
