package com.customerController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class customerController {
	@RequestMapping("/load")
	public String loadMyJspFile()
	{
		return "NewFile";
	}
	

}
