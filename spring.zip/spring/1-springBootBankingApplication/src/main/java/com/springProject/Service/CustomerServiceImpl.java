package com.springProject.Service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springProject.Model.Customer;
import com.springProject.Repository.CustomerRepository;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public void addCustomer(Customer customer) {
		customerRepository.save(customer);

	}

	@Override
	public List<Customer> findAllCustomers() {
		List<Customer> customer = customerRepository.findAll();
		return customer;
	}

	@Override
	public void deleteCustomerByaccountNumber(long accountNumber) {
		customerRepository.deleteByaccountNumber(accountNumber);

	}

	@Override
	public Optional<Customer> findCustomerByaccountNumber(long accountNumber) {
		return customerRepository.findByaccountNumber(accountNumber);

	}

	@Override
	public void updateCustomer(long accountNumber,Customer customer) {
		customerRepository.save(customer);

	}

	
	


	

}
