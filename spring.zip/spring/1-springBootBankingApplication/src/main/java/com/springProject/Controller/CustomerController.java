package com.springProject.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.springProject.Model.Customer;
import com.springProject.Service.CustomerService;
import com.springProject.exception.ResourceNotFoundException;

//@RestController
@Controller
@RequestMapping("/home")
public class CustomerController {
	@Autowired
	CustomerService customerservice;

	@RequestMapping("/")
	public String showUrl() {
		return "This is a authenticated user";
	}

	@PostMapping("/add")
	public void addCustomerinfo(@RequestBody Customer customer) {
		customerservice.addCustomer(customer);

	}

	@GetMapping("/getAll")
	public List<Customer> getAllUsers() {
		List<Customer> customer = customerservice.findAllCustomers();

		customerservice.findAllCustomers();
		return customer;

	}

	@RequestMapping(value = "/customer1/{accountNumber}", method = RequestMethod.DELETE)
	public void deleteByaccountNumber(@PathVariable("accountNumber") long accountNumber) {
		customerservice.deleteCustomerByaccountNumber(accountNumber);
	}

	@PostMapping("/update/{accountNumber}")
	public void updateCustomer(@PathVariable("accountNumber") long accountNumber, Customer customer) {
		customerservice.updateCustomer(accountNumber, customer);
	}

	

	
	



	

}
