package com.springProject.Service;

import java.util.List;
import java.util.Optional;

import com.springProject.Model.Customer;

public interface CustomerService {
	public void addCustomer(Customer customer);

	public List<Customer> findAllCustomers();

	public void deleteCustomerByaccountNumber(long accountNumber);



	public Optional<Customer> findCustomerByaccountNumber(long accountNumber);

	public void updateCustomer(long accountNumber, Customer customer);




}
