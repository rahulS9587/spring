package com.springProject.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springProject.Model.User;
import com.springProject.Repository.userRepository;
@Service
public class userServiceImpl implements userService{
	
	@Autowired
userRepository userrepository;
	

	@Override
	public void addUser(User user) {
		userrepository.save(user);
	}

}
