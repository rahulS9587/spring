package com.springProject.Service;

import com.springProject.Model.User;

public interface userService {
	public void addUser(User user);

}
