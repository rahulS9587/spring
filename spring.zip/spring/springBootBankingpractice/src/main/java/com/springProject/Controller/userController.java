package com.springProject.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springProject.Model.User;
import com.springProject.Service.userService;

@RestController
@RequestMapping("/v1")
public class userController {
	@Autowired
	userService userservice;
	 @PostMapping("/add")
	public void addCustomerinfo(@RequestBody User user) {
		userservice.addUser(user);

	}
	
	

}
