package com.springProject.Controller;

public class adminController {

}
