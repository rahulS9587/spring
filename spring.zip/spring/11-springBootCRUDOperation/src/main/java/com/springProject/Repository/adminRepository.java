package com.springProject.Repository;

import org.springframework.stereotype.Repository;

@Repository
public interface adminRepository  {

}
