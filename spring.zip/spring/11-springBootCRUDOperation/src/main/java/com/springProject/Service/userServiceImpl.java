package com.springProject.Service;

public class userServiceImpl implements adminService {

}
