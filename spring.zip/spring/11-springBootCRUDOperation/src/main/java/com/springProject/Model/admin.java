package com.springProject.Model;

public class admin {

}
