package com.springProject.Service;

public interface adminService {

}
