package com.springProject.Exception;

public class MinimumBalanceException extends RuntimeException {
	
	public MinimumBalanceException(String message){
		
		super(message);
	}

}
