package com.springProject.Controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springProject.Exception.ResourceNotFoundException;
import com.springProject.Exception.Transfer;
import com.springProject.Model.Customer;
import com.springProject.Service.CustomerService;

@RestController
@RequestMapping("/v1")
public class CustomerController  {
	@Autowired
	CustomerService customerservice;
	

	
	Logger logger = LoggerFactory.getLogger(CustomerController.class);
//	@PreAuthorize("hasRole('ADMIN')")
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public ResponseEntity<Void> addCustomerinfo(@Valid @RequestBody Customer customer) {
		logger.info("This is Post Method");
		customerservice.addCustomer(customer);
		return new ResponseEntity<Void>(HttpStatus.OK);
		
	}
//	@PreAuthorize("hasRole('ADMIN')")
	@RequestMapping("/customer")
	public List<Customer> getAllUsers() {
		List<Customer> customer = customerservice.fetchAllCustomers();
		logger.info("This is get method for get all users");
		customerservice.fetchAllCustomers();
		return customer;
		
			
	}
	

	//@PreAuthorize("hasRole('USER')")
	@RequestMapping("/bal/{accountNumber}")
    public ResponseEntity<String> getBalance(@PathVariable("accountNumber") long accountNumber) {
      
        return customerservice.checkBalance(accountNumber);
    }
//	@PreAuthorize("hasRole('USER')")
	@RequestMapping(value="/credit/{accountNumber}/{amount}",method=RequestMethod.POST)
    public ResponseEntity<String> Credit(@PathVariable("accountNumber") long accountNumber,@PathVariable("amount") long amount) {
		
        return customerservice.credit(accountNumber, amount);
      
    }
//	@PreAuthorize("hasRole('USER')")
	@RequestMapping(value="/debit/{accountNumber}/{amount}",method=RequestMethod.POST)
    public ResponseEntity<String> Debit(@PathVariable("accountNumber") long accountNumber,@PathVariable("amount") long amount) {
		
        return customerservice.debit(accountNumber, amount);
      
    }
//	@PreAuthorize("hasRole('USER')")
	@RequestMapping(value="/transfer/{from}/{to}/{amount}",method=RequestMethod.POST)
    public ResponseEntity<Transfer> Transferfund(@PathVariable("from") long from,@PathVariable("to") long to,@PathVariable("amount") long amount) {
		
        return customerservice.transfer(from,to, amount);
        
      
    }
	
		
	//@PreAuthorize("hasRole('USER')")
	@RequestMapping("/get/{accountNumber}")
    public ResponseEntity<Customer> getCustomerByaccountNumber(@PathVariable("accountNumber") long accountNumber) {
        return customerservice.findByaccountNumber(accountNumber);
    }
//	@PreAuthorize("hasRole('ADMIN')")
	@DeleteMapping(value = "/delete/{accountNumber}")
	public ResponseEntity<Void> deletecustomerByaccountNumber(@PathVariable("accountNumber") long accountNumber) {
		customerservice.deleteByaccountNumber(accountNumber);
		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);

	}
	@GetMapping("/fetch/{customerName}")
	public void getCustomerByCustomerName(@PathVariable("customerName") String customerName) {
		 customerservice.findByCustomerName(customerName);
		
	}
	@PutMapping("/customer/{accountNumber}")
	public Customer UpdateCustomer(@Valid @RequestBody Customer customer, @PathVariable("accountNumber") long accountNumber)
			throws ResourceNotFoundException{ 
		customerservice.findByaccountNumber(accountNumber);
			customerservice.updateCustomer(customer, accountNumber);
			return customer;

	}
	
 
	

	
}
