package com.springProject.Service;

import com.springProject.Model.Transaction;

public interface TransactionService {

	
	 public void transa(Transaction t);
}
