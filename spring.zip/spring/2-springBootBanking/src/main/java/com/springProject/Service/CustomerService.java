package com.springProject.Service;

import java.util.List;

import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.springProject.Exception.Transfer;
import com.springProject.Model.Customer;

public interface CustomerService {
	
	public void addCustomer(Customer customer);
	public List<Customer> fetchAllCustomers();
	public Customer findByCustomerName(String customerName);
	public Customer updateCustomer(Customer customer,long accountNumber);
	public void deleteByaccountNumber(long accountNumber);
    
    public ResponseEntity<Customer> findByaccountNumber(long id);
    
    public ResponseEntity<String> checkBalance(long id);
    
    public ResponseEntity<String> credit(long accno, long amount);
    public ResponseEntity<String> debit(long accno, long amount);
    public ResponseEntity<Transfer> transfer(long fromAccno,long toAccno,long amount);
    
   
}
