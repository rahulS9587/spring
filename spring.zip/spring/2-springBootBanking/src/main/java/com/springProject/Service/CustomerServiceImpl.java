package com.springProject.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.springProject.Exception.AccountNotFoundException;
import com.springProject.Exception.LimitExceedException;
import com.springProject.Exception.MinimumBalanceException;
import com.springProject.Exception.Transfer;
import com.springProject.Model.Customer;
import com.springProject.Model.Transaction;
import com.springProject.Repository.CustomerRepository;
import com.springProject.Repository.TransactionRepository;

@Service
public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	TransactionRepository transactionRepository;

	@Override
	public void addCustomer(Customer customer) {
		customerRepository.save(customer);
	}

	@Override
	public List<Customer> fetchAllCustomers() {
		List<Customer> customer = customerRepository.findAll();
		System.out.println("getting data from db: " + customer);
		return customer;
	}

	@Override
	public ResponseEntity<Customer> findByaccountNumber(long id) {
		Optional<Customer> customer = customerRepository.findByAccountNumber(id);
		if (customer.isPresent())
			return ResponseEntity.ok(customer.get());
		throw new AccountNotFoundException("Invalid Customer");
	}

	@Override
	public ResponseEntity<String> checkBalance(long id) {
		Optional<Customer> customer = customerRepository.findByAccountNumber(id);
		if (customer.isPresent())
			return ResponseEntity.ok("Your Balance is: " + customer.get().getAmount());
		throw new AccountNotFoundException("Invalid Customer");
	}

	@Override
	public ResponseEntity<String> credit(long accno, long amount) {
		Optional<Customer> customer = customerRepository.findByAccountNumber(accno);
		if (customer.isPresent()) {

			if (amount > 10000) {
				throw new LimitExceedException("You can't debit more than 10000 in a single time :)");
			} else {
				long bal = customer.get().getAmount();
				String name = customer.get().getCustomerName();
				long new_balance = bal + amount;

				customer.get().setAmount(new_balance);
				String msg = "successfully credited " + amount + " In " + name + " account";
				Transaction t = new Transaction();
				t.setMsg(msg);
				t.setAccno(accno);
				transactionRepository.save(t);
				return ResponseEntity.ok(msg);
			}
		} else {
			throw new AccountNotFoundException("Invalid Customer");

		}
	}

	@Override
	public ResponseEntity<String> debit(long accno, long amount) {
		Optional<Customer> customer = customerRepository.findByAccountNumber(accno);
		if (customer.isPresent()) {
			long id = customer.get().getAccountNumber();
			long bal = customer.get().getAmount();
			if (bal > 1000) {
				String name = customer.get().getCustomerName();
				Customer cust = customerRepository.findByCustomerName(name);
				long new_balance = bal - amount;
				customer.get().setAmount(new_balance);
				String msg = "successfully debited " + amount + " In " + name + " account";

				Transaction t = new Transaction();
				t.setMsg(msg);
				t.setAccno(accno);
				// post
				transactionRepository.save(t);
				// customerRepository.save(c);
				return ResponseEntity.ok(msg);
			} else {

				throw new MinimumBalanceException("You can't debit. Minimum Balance should be 1000.");
			}
		}

		else {
			throw new AccountNotFoundException("Invalid Customer");
		}
	}

	@Override
	public ResponseEntity<Transfer> transfer(long fromAccno, long toAccno, long amount) {
		CustomerServiceImpl customerService = new CustomerServiceImpl();

		Optional<Customer> customer = customerRepository.findByAccountNumber(fromAccno);

		Optional<Customer> customer2 = customerRepository.findByAccountNumber(toAccno);

		if (customer.isPresent() && customer2.isPresent()) {
			if (customer.get().getAmount() > amount + 1000) {

				if (amount < 10000) {

					// debit

					long id = customer.get().getAccountNumber();
					long bal = customer.get().getAmount();

					String name = customer.get().getCustomerName();
					// Customer cust = customerRepository.findByCustomerName(name);

					long new_balance = bal - amount;

					customer.get().setAmount(new_balance);
					// customer2
					long id2 = customer2.get().getAccountNumber();
					String name2 = customer2.get().getCustomerName();

					String msg = "successfully debited " + amount + " In " + name + " account and deposted in " + name2
							+ " account";

					Transaction t = new Transaction();
					t.setMsg(msg);
					t.setAccno(toAccno);

					transactionRepository.save(t);
					// customerRepository.save(c);
					// credit

					long bal2 = customer.get().getAmount();
					String name3 = customer.get().getCustomerName();
					long new_balance2 = bal2 + amount;

					customer.get().setAmount(new_balance2);

					String msg2 = "successfully credited " + amount + " to your  " + name3 + " account";
					Transaction t2 = new Transaction();

					t2.setMsg(msg2);
					t2.setAccno(toAccno);

					transactionRepository.save(t2);

					Transfer transfer = new Transfer(msg, msg2, new Date());

					return ResponseEntity.ok(transfer);

				} else {
					throw new LimitExceedException("Insuffiencent Balance");
				}

			} else {
				throw new MinimumBalanceException("You can't debit. Minimum Balance should be 1000.");

			}
		}

		else {
			throw new AccountNotFoundException("Invalid Customer");
		}
	}

	@Override
	public void deleteByaccountNumber(long accountNumber) {
		customerRepository.deleteByaccountNumber(accountNumber);
	}

	@Override
	public Customer findByCustomerName(String customerName) {
		return customerRepository.findByCustomerName(customerName);

	}
	@Override
	public Customer updateCustomer(Customer customer, long accountNumber) {
		customerRepository.findByAccountNumber(accountNumber);
		String custName=customer.getCustomerName();
		customer.setCustomerName(custName);
		customerRepository.save(customer);
		return customer;
	}


}
