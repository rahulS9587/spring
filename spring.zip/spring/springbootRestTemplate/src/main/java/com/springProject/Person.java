package com.springProject;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@Entity
@Table(name="person_data")
public class Person{
	
	@javax.persistence.Id
	BigInteger Id;
	String firstname;
	String lastname;
	public Person() {
		super();
	}
	public Person(BigInteger id, String firstname, String lastname) {
		super();
		Id = id;
		this.firstname = firstname;
		this.lastname = lastname;
	}
	public BigInteger getId() {
		return Id;
	}
	public void setId(BigInteger id) {
		Id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLast_name() {
		return lastname;
	}
	public void setLast_name(String lastname) {
		this.lastname = lastname;
	}
	public String getFullName() {
		return this.firstname+" "+this.lastname;
	}
	
	  @Override public String toString() { return "Person [Id=" + Id +
	  ", firstname=" + firstname + ", lastname=" + lastname + "]"; }
	 
	
}
@Service
class PersonService{
	@Autowired
	PersonRepository personrepository;
	
	public void addPerson(Person person) {
		personrepository.save(person);
	}
	
	
	List<Person> findAll(){
		return personrepository.findAll();
	}
}
@Repository
interface PersonRepository extends JpaRepository<Person, Long>{
	
	
}

@RestController
@RequestMapping("/v1")
class PersonController{
	
	@Autowired
	PersonService personservice;
	
	@RequestMapping("/add")
	public void addperson(@RequestBody Person person) {
		personservice.addPerson(person);
		
		
	}
	@RequestMapping("/findAll")
	public List<Person> findall() {
		List<Person> person=personservice.findAll();
		return person;
	}

	
}
