package com.springProject;

import org.springframework.data.jpa.repository.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.transaction.annotation.*;
import org.springframework.web.bind.annotation.*;

import javax.persistence.*;
import java.util.logging.Logger;
import java.util.logging.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;
import javax.persistence.*;
import org.springframework.data.jpa.repository.*;
 
 
//I have imported only these two packages. 
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Entity
class Task {
        @Id
       long id;
       
       String description;
       
       long priority;
 
       public Task() {
       }
 
       public Task(long id, String description, long priority) {
             this.id = id;
             this.description = description;
             this.priority = priority;
       }
 
       public long getId() {
             return id;
       }
 
       public void setId(long id) {
             this.id = id;
       }
 
       public String getDescription() {
             return description;
       }
 
       public void setDescription(String description) {
             this.description = description;
       }
 
       public long getPriority() {
             return priority;
       }
 
       public void setPriority(long priority) {
             this.priority = priority;
       }

}
@RestController
class TaskController {
       private final TaskRepository repo;
       
       
       public TaskController(TaskRepository repo) {
             this.repo = repo;
       }
 
       private static Logger log = Logger.getLogger("Solution");
         // log.info("You can use 'log' for debug messages");
         
         @PutMapping("/tasks/{id}")
 
         update update(@PathVariable("id")long id,@RequestBody Task task){
             Task task1= repo.findById(id).orElse(null);
               if(task1==null) {
                      throw new TaskNotFound("cannot find task with the given id");
               }else if(task.getDescription().isEmpty() || task.getDescription()==null) {
                      throw new DescriptionNotFound("task description is required");
               }else {
             repo.updateproduct(id, task.getDescription(),task.getPriority());
             update up=new update();
             up.setDescription(task.getDescription());
             up.setPriority(task.getPriority());
             return up;
               }
         }
  
}

interface TaskRepository extends JpaRepository<Task, Long> {
           @Transactional
           @Modifying
           @Query(value="update task t set t.description=:description,t.priority=:priority where t.id=:id",nativeQuery=true)
       void updateproduct (@Param("id")long id,@Param("description")String description,@Param("priority")long priority);

}

class ErrorDetails{
       String message;
       int statuscode;
       public ErrorDetails() {
       }
       
       public ErrorDetails(String message, int statuscode) {
             this.message = message;
             this.statuscode = statuscode;
       }
 
       public String getMessage() {
             return message;
       }
 
       public void setMessage(String message) {
             this.message = message;
       }
 
       public int getStatuscode() {
             return statuscode;
       }
 
       public void setStatuscode(int statuscode) {
             this.statuscode = statuscode;
       }
       
       
}
 
class update{
       String description;
       long priority;
       public update() {
       }
       
       public String getDescription() {
             return description;
       }
 
       public void setDescription(String description) {
             this.description = description;
       }
 
       public long getPriority() {
             return priority;
       }
 
       public void setPriority(long priority) {
             this.priority = priority;
       }
 
       public update(String description, long priority) {
             this.description = description;
             this.priority = priority;
       }
       
       
}
 
class TaskNotFound extends RuntimeException{
       
       private String message;
 
       public TaskNotFound(String message) {
             super(message);
             this.message=message;
       }
       
}
       class DescriptionNotFound extends RuntimeException{
             
             private String message;
 
             public DescriptionNotFound(String message) {
                    super(message);
                    this.message=message;
             }
       }
       
//        @ControllerAdvice
//        class GlobalExceptionHandler {
             
//              @ExceptionHandler(TaskNotFound.class)
//            public ResponseEntity<?> resourceNotFoundException(TaskNotFound ex,WebRequest request)
//            {      
//                     ErrorDetails errorDetails=new ErrorDetails(ex.getMessage(),HttpStatus.NOT_FOUND.value());
//            return new ResponseEntity<>(errorDetails,HttpStatus.NOT_FOUND);
//            }
                    
//              @ExceptionHandler(DescriptionNotFound.class)
//            public ResponseEntity<?> descriptionNotFoundException(DescriptionNotFound ex,WebRequest request)
//            {      
//                     ErrorDetails errorDetails=new ErrorDetails(ex.getMessage(),HttpStatus.BAD_REQUEST.value());
//            return new ResponseEntity<>(errorDetails,HttpStatus.BAD_REQUEST);
//            }
             
 
// }

