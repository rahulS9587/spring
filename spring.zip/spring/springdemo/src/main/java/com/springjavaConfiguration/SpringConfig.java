package com.springjavaConfiguration;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.springjavaConfiguration")
public class SpringConfig {

	
	
	  @Bean(name="person1")
	  public Person person1Bean() {
		  Person person=new Person(); 
		  person.setId(100);
		  person.setName("ABC"); 
		  return person; 
		  }
	 
}
