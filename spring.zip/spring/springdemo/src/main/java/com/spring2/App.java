package com.spring2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
		System.out.println("hello world");
		ApplicationContext context = new ClassPathXmlApplicationContext("com/spring2/config.xml");
		//Person p = (Person) context.getBean("person1", Person.class);
		//System.out.println(p);
		Addition a = (Addition) context.getBean("add", Addition.class);
		a.doSum();

	}

}
