package com.spring2;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class autowiredAnnotation {
	public static void main(String[] args) {
	ApplicationContext context=new ClassPathXmlApplicationContext("config.xml");
	
		Address person = context.getBean("add1", Address.class);
		 System.out.println(person);
		 
		//  ApplicationContext context1 = new
		//  ClassPathXmlApplicationContext("config.xml"); // Customer Customer customer1
		  Customer customer1= context.getBean("cust1", Customer.class);
		  System.out.println(customer1);
		 
//	 BeanFactory factory = new XmlBeanFactory(new ClassPathResource("config.xml"));
//	 factory.getBean("cust1", Customer.class);
			 
	}

}
