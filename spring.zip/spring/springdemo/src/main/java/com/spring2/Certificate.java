package com.spring2;

public class Certificate {
	int certiId;
	String CertiName;
	public Certificate(int certiId, String certiName) {
		super();
		this.certiId = certiId;
		this.CertiName = certiName;
	}
	@Override
	public String toString() {
		return "Certificate [certiId=" + certiId + ", CertiName=" + CertiName + "]";
	}

	

}
