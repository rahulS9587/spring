package com.spring2;

import java.util.List;

public class Person {
	String personName;
	String personId;
	List<Certificate> certi;
	public Person(String personName, String personId,List<Certificate> certi) {
		super();
		this.personName = personName;
		this.personId = personId;
		this.certi=certi;
	}
	@Override
	public String toString() {
		return "Person [personName=" + personName + ", personId=" + personId + ", certi=" + certi + "]";
	}

	

}
