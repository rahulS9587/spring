package com.spring1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello world");
		// using ref or normal creation of object
		/*
		 * ApplicationContext context=new ClassPathXmlApplicationContext("config.xml");
		 * Customer cust1=(Customer)context.getBean("Customer1",Customer.class);
		 * System.out.println(cust1);
		 */
		ApplicationContext context=new ClassPathXmlApplicationContext("com/spring1/config.xml");
		empCollection emp=(empCollection)context.getBean("empCollection1",empCollection.class);
		System.out.println(emp);
	
	}

}
