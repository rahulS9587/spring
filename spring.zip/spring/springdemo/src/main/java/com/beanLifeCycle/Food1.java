package com.beanLifeCycle;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Food1 implements InitializingBean,DisposableBean {
	int price;

	public Food1() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Food1(int price) {
		super();
		this.price = price;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Food1 [price=" + price + "]";
	}

	public void destroy() throws Exception {
		System.out.println("destroyed");
		// TODO Auto-generated method stub
		
	}

	public void afterPropertiesSet() throws Exception {
		System.out.println("taking food");
		// TODO Auto-generated method stub
		
	}
	

}
