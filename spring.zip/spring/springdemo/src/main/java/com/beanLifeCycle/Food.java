package com.beanLifeCycle;

public class Food {
	int price;
	String name;
	public Food(int price, String name) {
		super();
		this.price = price;
		this.name = name;
	}
	public Food() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		System.out.println("setting price");
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		System.out.println("setting name");
		this.name = name;
	}
	@Override
	public String toString() {
		return "Food [price=" + price + ", name=" + name + "]";
	}
	public void init() {
		System.out.println("inside init method");
	}
	public void destroy() {
		System.out.println("inside destroy");
	}

}
