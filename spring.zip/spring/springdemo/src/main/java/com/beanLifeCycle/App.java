package com.beanLifeCycle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
	AbstractApplicationContext context=new ClassPathXmlApplicationContext("com/beanLifeCycle/config.xml");
	//	Food food=(Food) context.getBean("food1",Food.class);
	// using init() and destroy() method;
	//	System.out.println(food);
		context.registerShutdownHook();
// using interfaces;
		Food1 food1=(Food1) context.getBean("food2",Food1.class);
		System.out.println(food1);
	}

}
