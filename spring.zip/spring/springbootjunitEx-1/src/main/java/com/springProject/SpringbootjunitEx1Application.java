package com.springProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootjunitEx1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootjunitEx1Application.class, args);
	}

}
