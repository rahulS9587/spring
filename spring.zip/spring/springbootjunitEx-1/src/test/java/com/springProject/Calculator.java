package com.springProject;

public class Calculator {
	public int doSum(int a,int b,int c) {
		return a+b+c;
	}
	
	public int doMulti(int a,int b) {
		return a*b;
	}
	public boolean compareTwoNums(int a,int b) {
		return a==b;
	}

	

}
