package com.springProject;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

class NullPointerTest {

	//@Test
//	void test() {
	//	fail("Not yet implemented");
	//}
	@Test
	void testArraySort() {
		int [] withoutSort= {24,44,23,45,67,4};	
		int [] sortedArray= {4,23,24,44,45,67};
		Arrays.sort(withoutSort);
		
		assertArrayEquals(sortedArray, withoutSort);
		
	}
	
	/*
	 * @Test void testArrayNullArray() { assertThrows(NullPointerTest.class,()->{
	 * int[] number=null; Arrays.sort(number); }); }
	 * 
	 */
}
