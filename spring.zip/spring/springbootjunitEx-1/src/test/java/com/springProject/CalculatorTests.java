package com.springProject;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@TestInstance(Lifecycle.PER_CLASS)
class CalculatorTests {
	Calculator c;

//	@BeforeAll
	@BeforeEach
	void initializeObjectforMethodCall() {
//	Calculator c=new Calculator();
		c = new Calculator();
		System.out.println("object created...."+c);
		
	}

	@Test
	void contextLoads() {
		System.out.println("hello");

	}

	@Test
	void testSum() {
		// c=new Calculator();

		int expectedResult = 24;

		int actualResult = c.doSum(12, 5, 7);

		assertThat(actualResult).isEqualTo(expectedResult);

	}

	@Test
	void testMulti() {

		int expectedResult = 60;
		int actualResult = c.doMulti(12, 5);
		assertThat(actualResult).isEqualTo(expectedResult);
	}

	@Test
	void testTwoNums() {

		boolean actualResult = c.compareTwoNums(3, 3);
		assertThat(actualResult).isTrue();

	}

	//@AfterAll
	@AfterEach
	void closeResourceAfterEveryMethod() {
		System.out.println("execution of program done....");
	}

}
