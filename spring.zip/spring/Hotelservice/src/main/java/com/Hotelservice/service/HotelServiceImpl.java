package com.Hotelservice.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Hotelservice.exception.ResourceNotFoundException;
import com.Hotelservice.model.Hotel;
import com.Hotelservice.repository.HotelRepository;

@Service
public class HotelServiceImpl implements HotelService {
	
	@Autowired
	private HotelRepository hotelrepo;
	
	@Override
	public Hotel create(Hotel hotel) {
		String randomHotelId=UUID.randomUUID().toString();
		hotel.sethotelId(randomHotelId);
		return hotelrepo.save(hotel);
		
	}

	@Override
	public Hotel get(String hotelid) {
		return hotelrepo.findById(hotelid).orElseThrow(()-> new ResourceNotFoundException("hotel with this given id is not found!!"));
	}

	@Override
	public List<Hotel> findAll() {
		
		return hotelrepo.findAll();
	}

}
