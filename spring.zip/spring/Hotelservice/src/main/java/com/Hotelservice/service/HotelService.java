package com.Hotelservice.service;

import java.util.List;

import com.Hotelservice.model.Hotel;

public interface HotelService {
	public Hotel create(Hotel hotel);
	
	public Hotel get(String hotelid);
	
	public List<Hotel> findAll();

}
