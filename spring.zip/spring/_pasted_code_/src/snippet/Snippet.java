package snippet;

public class Snippet {
	<form action="login" method="post" modelAttribute="custObj">
	
}

