package com.springProject.Service;

import java.util.List;
import java.util.Optional;

import com.springProject.Model.Customer;

public interface CustomerService {
	public void addCustomer(Customer customer);

	public List<Customer> fetchAllCustomers();

	public Customer findByaccountNumber(long id);

	public void deleteCustomerByaccountNumber(long accountNumber);

	public Optional<Customer> findBycontactDetails(long contactDetails);

	public long checkBalance(long id);

	public void credit(long accno, long amount);

	public void debit(long accno, long amount);

	public void transfer(long fromAccno, long toAccno, long amount);
}
