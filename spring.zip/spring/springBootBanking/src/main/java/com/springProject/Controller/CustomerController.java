package com.springProject.Controller;

import java.util.List;

import java.util.Optional;

import javax.swing.text.html.FormSubmitEvent.MethodType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.springProject.Model.Customer;
import com.springProject.Service.CustomerService;
import com.springProject.exception.ResourceNotFoundException;

@RestController
@RequestMapping("/v1")
public class CustomerController {
	@Autowired
	CustomerService customerservice;

	@RequestMapping("/check")
	public String checkUrl() {
		return "Hello this is Authenticated User";
	}

	@RequestMapping(value = "/customer", method = RequestMethod.POST)
	public ResponseEntity<Void> addCustomerinfo(@RequestBody Customer customer) {
		customerservice.addCustomer(customer);
		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);

	}
	/*
	 * @RequestMapping(value = "/customer", method = RequestMethod.POST) public void
	 * addCustomerinfo(@RequestBody Customer customer) {
	 * customerservice.addCustomer(customer); }
	 */

	@RequestMapping("/customer")
	public ResponseEntity<List<Customer>> getAllUsers() {
		List<Customer> customer = customerservice.fetchAllCustomers();

		customerservice.fetchAllCustomers();
		return new ResponseEntity<List<Customer>>(customer, HttpStatus.OK);

	}

	@RequestMapping("/customer/{accountNumber}")
	public Customer getCustomerByaccountNumber(@PathVariable("accountNumber") long accountNumber) {
		Customer customer = customerservice.findByaccountNumber(accountNumber);
		return customer;
	}

	@RequestMapping(value = "/delete/{accountNumber}", method = RequestMethod.DELETE)
	public ResponseEntity<Void> deletecustomerByaccountNumber(@PathVariable("accountNumber") long accountNumber) {
		customerservice.deleteCustomerByaccountNumber(accountNumber);
		return new ResponseEntity<Void>(HttpStatus.ACCEPTED);

	}

	@RequestMapping("/bal/{accountNumber}")
	public long getBalance(@PathVariable("accountNumber") long accountNumber) {
		long customer = customerservice.checkBalance(accountNumber);
		return customer;
	}

	@RequestMapping(value = "/credit/{accountNumber}/{amount}", method = RequestMethod.POST)
	public void Credit(@PathVariable("accountNumber") long accountNumber, @PathVariable("amount") long amount) {

		customerservice.credit(accountNumber, amount);

	}

	@RequestMapping(value = "/debit/{accountNumber}/{amount}", method = RequestMethod.POST)
	public void Debit(@PathVariable("accountNumber") long accountNumber, @PathVariable("amount") long amount) {

		customerservice.debit(accountNumber, amount);

	}

	@RequestMapping(value = "/transfer/{from}/{to}/{amount}", method = RequestMethod.POST)
	public void Debit(@PathVariable("from") long from, @PathVariable("to") long to,
			@PathVariable("amount") long amount) {

		customerservice.transfer(from, to, amount);

	}

	@RequestMapping("/find/{contactDetails}")
	public ResponseEntity<Customer> getBycontactDetails(@PathVariable("contactDetails") long contactDetails) {
		Optional<Customer> customer = customerservice.findBycontactDetails(contactDetails);
		if (customer.isPresent())
			return ResponseEntity.ok(customer.get());
		throw new ResourceNotFoundException("Invalid Customer");

	}

}
